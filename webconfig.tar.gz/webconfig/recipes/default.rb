#
# Cookbook:: webconfig
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

package 'httpd' do
 action :install
end

template '/var/www/html/index.html' do
   source 'index.html.erb'
end

template '/etc/httpd/conf.d/virtualhost.conf' do
   source 'virtualhost.conf.erb'
end

service 'httpd' do
  action :restart
end

package 'tomcat7' do
  action :install
end

service 'tomcat7' do
 action :restart
end

directory '/var/www/html/aws' do
   action :create
   recursive true
end

directory '/var/www/html/devops' do
   action :create
   recursive true
end

package 'elinks' do
  action :install
end

bash 'echo "127.0.0.1 devops.com aws.com localhost" >> /etc/hosts"'
