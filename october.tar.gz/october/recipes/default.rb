#
# Cookbook:: october
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
package 'httpd' do
  action :install
end

service 'httpd' do
  action :restart
end

#file '/var/www/html/index.html' do
#  content "Welcome to Chef"
#end

template '/var/www/html/index.html' do
  source 'index.html.erb'
end
