package 'httpd' do
  action :install
end

service 'httpd' do
  action :restart
end

file '/var/www/html/index.html' do
  content "Welcome to Chef"
end
